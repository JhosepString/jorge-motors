import { app, BrowserWindow, shell } from 'electron';
import { join } from 'node:path';
import { startStaticServer } from './static-server.mjs';

let window;
let staticServer;
app.on('window-all-closed', () => app.quit());
app.whenReady().then(async () => {
  const { server, origin } = await startStaticServer(join(app.getAppPath(), 'frontend'), 5173);
  staticServer = server;
  window = new BrowserWindow({ width: 1280, height: 820, minWidth: 900, minHeight: 650,
    title: 'Jorge Motors', webPreferences: { nodeIntegration: false, contextIsolation: true,
      sandbox: true, webSecurity: true } });
  window.webContents.setWindowOpenHandler(({ url }) => {
    const target = new URL(url);
    if (target.protocol === 'https:' && target.hostname === 'login.microsoftonline.com') void shell.openExternal(url);
    return { action: 'deny' };
  });
  window.webContents.on('will-navigate', (event, url) => {
    if (!url.startsWith(origin + '/')) event.preventDefault();
  });
  await window.loadURL(origin);
}).catch((error) => { console.error(error); app.quit(); });
app.on('before-quit', () => staticServer?.close());
